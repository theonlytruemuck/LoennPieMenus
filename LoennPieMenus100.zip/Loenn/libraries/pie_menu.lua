print("library says hello o/")
local hotkeyHandler = require("hotkey_handler")
local sceneHandler = require("scene_handler")
local viewportHandler = require("viewport_handler")
local inputHandler = require("input_handler")
local toolHandler = require("tools")
local placementUtils = require("placement_utils")
local brushHelper = require("brushes")
local serialize = require("utils.serialize")
local settings = require("mods").requireFromPlugin("consts.settings")
local font = love.graphics.newFont(16)

local emptyTool = {
	_type = "tool",
	name = "name",
	group = "group"
}

local pieMenuDevice = {
    _type = "device",
    name = "pieMenuDeviceTrigger",
    _enabled = true,
	isTabPressed = false,
	tabPressedTime = 0,
	lastTool = nil,
	lastMode = nil,
	lastLayer = nil,

	boxX = 0,
	boxY = 0,

	openMenu = nil,
	boxTexts = {"this is a default menu, if you see this something went wrong"},
	boxValues = {"if you see this, please dont ever touch a computer again. how the fuck did you manage to do break this plugin so badly?"}
}


-- TODO make the names for the tools not just the identifiers
function pieMenuDevice.openToolSelection()
	openMenu = "Tool"
	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool
	local tools = toolHandler.tools
	if tools then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for tool in pairs(tools) do
			table.insert(pieMenuDevice.boxValues,tool)
			table.insert(pieMenuDevice.boxTexts,tool)
		end
	end
end

function pieMenuDevice.closeToolSelection(name)
	openMenu = nil
	if name then
		toolHandler.selectTool(name)
	else
		toolHandler.currentTool = lastTool
	end
	lastTool = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end
-- TODO make the names for the layers not just the identifiers
function pieMenuDevice.openModeSelection()
	openMenu = "Mode"
	local name = toolHandler.currentToolName
	lastMode = toolHandler.getMode(name)
	local modes = toolHandler.getModes(name)

	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool

	if modes then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for _,mode in pairs(modes) do
			table.insert(pieMenuDevice.boxValues,mode)
			table.insert(pieMenuDevice.boxTexts,mode)
		end
	end
end

function pieMenuDevice.closeModeSelection(name)
	openMenu = nil
	if name then
		toolHandler.setMode(name)
	end
	lastMode = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end

function makeNameReadable(str)
	if not str then return "" end
	str = str:gsub("(%p)", " "):gsub("(%u)", " %1")
	str = str:gsub("[_%-]", " ")
	str = str:gsub("(%a)([%w_]*)", function(first, rest)
        return first:upper() .. rest:lower()
    end)

    return str
end

function valueIsInList(value,list)
	for _,testValue in pairs(list) do
		if testValue == value then
			return true
		end
	end
	return false
end

function pieMenuDevice.openMaterialSelection()
	openMenu = "Material"
	local name = toolHandler.currentToolName
	lastMaterial = toolHandler.getMaterial(name)

	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}

	local testLayer = toolHandler.getLayer(name)
	local brushes = {"brush","line","rectangle","circle","elipse","bucket"}

	if toolHandler.currentToolName == "placement" then
		local materials = placementUtils.getPlacements(testLayer)
		for key,material in pairs(materials) do
			if material.displayName then
				table.insert(pieMenuDevice.boxValues,key)
				table.insert(pieMenuDevice.boxTexts,tostring(material.displayName))
			end
		end
	elseif valueIsInList(toolHandler.currentToolName,brushes) then
		local materials = brushHelper.getTilerMeta(testLayer)
-- Air is not included in the tilesets. so i add it manually
		table.insert(pieMenuDevice.boxValues, "0")
		table.insert(pieMenuDevice.boxTexts, "Air")
		for key,material in pairs(materials) do
			local displayName = material.displayName
			    or makeNameReadable(material.path:match("tilesets/(.+)"))
			    or key
			table.insert(pieMenuDevice.boxValues,key)
			table.insert(pieMenuDevice.boxTexts,tostring(displayName))
		end
	else
		local materials = toolHandler.getMaterials(name)
		if materials then
			for _,material in pairs(materials) do
				table.insert(pieMenuDevice.boxValues,material)
				table.insert(pieMenuDevice.boxTexts,material)
			end
		end
	end
	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool
end

function pieMenuDevice.closeMaterialSelection(name)
	openMenu = nil
	if name then
		toolHandler.setMaterial(name)
		local currentName = toolHandler.currentToolName
		toolHandler.selectTool("selection")
		toolHandler.selectTool(currentName)
	end
	lastMaterial = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end
-- TODO make the names for the layers not just the identifiers
function pieMenuDevice.openLayerSelection()
	openMenu = "Layer"
	local name = toolHandler.currentToolName
	lastLayer = toolHandler.getLayer(name)
	local layers = toolHandler.getLayers(name)

	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool

	if layers then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for _,layer in pairs(layers) do
			table.insert(pieMenuDevice.boxValues,layer)
			table.insert(pieMenuDevice.boxTexts,layer)
		end
	end
end

function pieMenuDevice.closeLayerSelection(name)
	openMenu = nil
	if name then
		toolHandler.setLayer(name)
	end
	lastLayer = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end

function pieMenuDevice.closeLastMenu(name)
	if openMenu == "Tool" then pieMenuDevice.closeToolSelection(name) end
	if openMenu == "Layer" then pieMenuDevice.closeLayerSelection(name) end
	if openMenu == "Mode" then pieMenuDevice.closeModeSelection(name) end
	if openMenu == "Material" then pieMenuDevice.closeMaterialSelection(name) end
end


function pieMenuDevice.keypressed(key, scancode, isrepeat)
	if key == "tab" and not isrepeat then
		isTabPressed = true
		pieMenuDevice.boxX,pieMenuDevice.boxY = love.mouse.getPosition()

		if love.keyboard.isDown("lshift") and not love.keyboard.isDown("lctrl") then pieMenuDevice.openModeSelection() end
		if not love.keyboard.isDown("lshift") and love.keyboard.isDown("lctrl") then pieMenuDevice.openLayerSelection() end
		if love.keyboard.isDown("lshift") and love.keyboard.isDown("lctrl") then pieMenuDevice.openMaterialSelection() end
		if not love.keyboard.isDown("lshift") and not love.keyboard.isDown("lctrl") then pieMenuDevice.openToolSelection() end

		if settings.verboseLogging then
			print("labels:")
			for _,text in pairs(pieMenuDevice.boxTexts) do
				print("    "..text)
			end
			print("values:")
			for _,value in pairs(pieMenuDevice.boxValues) do
				print("    "..value)
			end
		end
	end
end

function pieMenuDevice.update(dt)
    if isTabPressed then
	    pieMenuDevice.tabPressedTime += 1
    end
end



function pieMenuDevice.keyreleased(key, scancode)
    if key == "tab" and isTabPressed then
	    isTabPressed = false

	    local name = nil
        if pieMenuDevice.getSelectedEntry() then
		     name = pieMenuDevice.boxValues[pieMenuDevice.getSelectedEntry()]
	    end
	    pieMenuDevice.closeLastMenu(name)
	    if toolHandler.currentTool == emptyTool then
			toolHandler.currentTool = lastTool
			toolHandler.selectTool(lastTool.name)
			lastTool = nil
		end

	    pieMenuDevice.tabPressedTime = 0
    end
end

function pieMenuDevice.getSelectedEntry()
		local x = pieMenuDevice.boxX
		local y = pieMenuDevice.boxY
		local mx,my = love.mouse.getPosition()

		local dx = mx-x
		local dy = my-y

		if dx*dx+dy*dy < (20*20) then return nil end

    local angle = math.atan2(dx, dy)
    if angle < 0 then angle = angle + (2 * math.pi) end

    local count = #pieMenuDevice.boxTexts
    local sliceAngle = (2 * math.pi) / count
    angle = angle - (sliceAngle / 2)
    if angle < 0 then angle = angle + (2 * math.pi) end
    local index = math.floor(angle / sliceAngle) % count + 1
    return index
end

function pieMenuDevice.draw()
	love.graphics.push()
	if isTabPressed then
		local x = pieMenuDevice.boxX
		local y = pieMenuDevice.boxY
		local texts = pieMenuDevice.boxTexts
		local radius = 100
		local count = #pieMenuDevice.boxTexts

		if count == 0 then
			love.graphics.pop()
			return
		end

		local sliceAngle = (2 * math.pi)/count

	--oooo funny magic numbers
		local padding = 6

		for i, option in ipairs(pieMenuDevice.boxTexts) do
		-- drow boxy
			local text = option
		    local textWidth = font:getWidth(text)
		    local textHeight = font:getHeight(text)

		    local offset = (textWidth*math.abs(math.sin(sliceAngle*i))+textHeight*math.abs(math.cos(sliceAngle*i)))*0.5
		    local X = x+math.sin(sliceAngle*i)*(radius+offset)
			local Y = y+math.cos(sliceAngle*i)*(radius+offset)

			love.graphics.setColor(0.1, 0.1, 0.1, 0.9)
			local selectedIndex = pieMenuDevice.getSelectedEntry()
			if option == toolHandler.currentToolName then love.graphics.setColor(0.1, 0.2, 0.4, 0.9) end
			if i==selectedIndex then love.graphics.setColor(0.2, 0.4, 0.8, 0.9) end
			love.graphics.rectangle("fill", X-(textWidth+padding)/2, Y-(textHeight+padding)/2, textWidth + (padding * 2), textHeight + (padding * 2), 4, 4)
			padding += 1
			love.graphics.setColor(0.9, 0.9, 0.9, 0.9)
			love.graphics.rectangle("line", X-(textWidth+padding)/2, Y-(textHeight+padding)/2, textWidth + (padding * 2), textHeight + (padding * 2), 4, 4)
			padding -= 1

		--drawy text
			love.graphics.setColor(1, 1, 1, 1)
		    love.graphics.print(text, font, X-(textWidth-padding)/2, Y-(textHeight-padding/2)/2)
	    end
	end
    love.graphics.pop()
end


local _sceneHandlerChangeScene = sceneHandler.changeScene
function sceneHandler.changeScene(name, ...)
    _sceneHandlerChangeScene(name, ...)

    if name == "Editor" then
        local scene = sceneHandler.scenes[name]

--         Check if device is already in the input device list adn add to list if not ig. this doesnt celan up properly idk why
        for i, dev in ipairs(scene.inputDevices) do
            if dev == pieMenuDevice then
	            table.remove(scene.inputDevices,i)
                break
            end
        end

        table.insert(scene.inputDevices, 4, pieMenuDevice)
    end
end
