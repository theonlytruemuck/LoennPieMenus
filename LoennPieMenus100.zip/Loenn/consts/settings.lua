local settings ={}
settings.verboseLogging = false
return settings
