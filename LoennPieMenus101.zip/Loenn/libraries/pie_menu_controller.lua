print("library says hello o/")
local hotkeyHandler = require("hotkey_handler")
local sceneHandler = require("scene_handler")
local viewportHandler = require("viewport_handler")
local inputHandler = require("input_handler")
local toolHandler = require("tools")
local utils = require("utils.utils")
local placementUtils = require("placement_utils")
local brushHelper = require("brushes")
local serialize = require("utils.serialize")
local settings = require("mods").requireFromPlugin("consts.settings")
local constructor = require("mods").requireFromPlugin("consts.pie_menu_constructor")
local font = settings.font

local emptyTool = {
	_type = "tool",
	name = "name",
	group = "group"
}

local pieMenuDevice = {
    _type = "device",
    name = "pieMenuDeviceTrigger",
    _enabled = true,
	isMasterPressed = false,
	masterPressedTime = 0,
	lastTool = nil,
	lastMode = nil,
	lastLayer = nil,

	boxX = 0,
	boxY = 0,

	openMenu = nil,
	boxTexts = {"this is a default menu, if you see this something went wrong"},
	boxValues = {"if you see this, please dont ever touch a computer again. how the fuck did you manage to do break this plugin so badly?"},

	currentPage = 1,
	selectedEntry = 1
}


function pieMenuDevice.openToolSelection()
	openMenu = "Tool"
	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool
	local tools = toolHandler.tools
	if tools then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for key,tool in pairs(tools) do
			table.insert(pieMenuDevice.boxValues,key)
			table.insert(pieMenuDevice.boxTexts,utils.humanizeVariableName(tool.name))
		end
	end
end

function pieMenuDevice.closeToolSelection(name)
	openMenu = nil
	if name then
		toolHandler.selectTool(name)
	else
		toolHandler.currentTool = lastTool
	end
	lastTool = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end
-- TODO make the names for the modes not just the identifiers
function pieMenuDevice.openModeSelection()
	openMenu = "Mode"
	local name = toolHandler.currentToolName
	lastMode = toolHandler.getMode(name)
	local modes = toolHandler.getModes(name)

	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool

	if modes then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for _,mode in pairs(modes) do
			table.insert(pieMenuDevice.boxValues,mode)
			table.insert(pieMenuDevice.boxTexts,mode)
		end
	end
end

function pieMenuDevice.closeModeSelection(name)
	openMenu = nil
	if name then
		toolHandler.setMode(name)
	end
	lastMode = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end

function valueIsInList(value,list)
	for _,testValue in pairs(list) do
		if testValue == value then
			return true
		end
	end
	return false
end

function pieMenuDevice.openMaterialSelection()
	openMenu = "Material"
	local name = toolHandler.currentToolName
	lastMaterial = toolHandler.getMaterial(name)

	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}

	local testLayer = toolHandler.getLayer(name)
	local brushes = {"brush","line","rectangle","circle","ellipse","bucket"}
	if toolHandler.currentToolName == "placement" then
		local materials = placementUtils.getPlacements(testLayer)
		for key,material in pairs(materials) do
			if material.displayName then
				table.insert(pieMenuDevice.boxValues,material.name)
				table.insert(pieMenuDevice.boxTexts,tostring(material.displayName))
			end
		end
	elseif valueIsInList(toolHandler.currentToolName,brushes) then
		local materials = brushHelper.getTilerMeta(testLayer)
-- Air is not included in the tilesets. so i add it manually
		table.insert(pieMenuDevice.boxValues, "0")
		table.insert(pieMenuDevice.boxTexts, "Air")
		for key,material in pairs(materials) do
			local displayName = material.displayName
			    or utils.humanizeVariableName(material.path:match("tilesets/(.+)"))
			    or key
			table.insert(pieMenuDevice.boxValues,key)
			table.insert(pieMenuDevice.boxTexts,tostring(displayName))
		end
	else
		local materials = toolHandler.getMaterials(name)
		if materials then
			for _,material in pairs(materials) do
				table.insert(pieMenuDevice.boxValues,material)
				--TODO im not sure if this can be an issue, but if there are custom tools with custom materials wich use some other system, i should add a fallback, that makes sure boxTexts is a string and never a table
				table.insert(pieMenuDevice.boxTexts,material)
			end
		end
	end
	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool
end

function pieMenuDevice.closeMaterialSelection(name)
	openMenu = nil
	if name then
		toolHandler.setMaterial(name)
		local currentName = toolHandler.currentToolName
		toolHandler.selectTool("selection")
		toolHandler.selectTool(currentName)
	end
	lastMaterial = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end
-- TODO make the names for the layers not just the identifiers
function pieMenuDevice.openLayerSelection()
	openMenu = "Layer"
	local name = toolHandler.currentToolName
	lastLayer = toolHandler.getLayer(name)
	local layers = toolHandler.getLayers(name)

	lastTool = toolHandler.currentTool
	toolHandler.currentTool = emptyTool

	if layers then
		pieMenuDevice.boxValues = {}
		pieMenuDevice.boxTexts = {}
		for _,layer in pairs(layers) do
			table.insert(pieMenuDevice.boxValues,layer)
			table.insert(pieMenuDevice.boxTexts,layer)
		end
	end
end

function pieMenuDevice.closeLayerSelection(name)
	openMenu = nil
	if name then
		toolHandler.setLayer(name)
	end
	lastLayer = nil
	pieMenuDevice.boxValues = {}
	pieMenuDevice.boxTexts = {}
end

function pieMenuDevice.closeLastMenu(name)
	if openMenu == "Tool" then pieMenuDevice.closeToolSelection(name) end
	if openMenu == "Layer" then pieMenuDevice.closeLayerSelection(name) end
	if openMenu == "Mode" then pieMenuDevice.closeModeSelection(name) end
	if openMenu == "Material" then pieMenuDevice.closeMaterialSelection(name) end
end


function pieMenuDevice.keypressed(key, scancode, isrepeat)
	if key == settings.keys.masterKey and not isrepeat then
		pieMenuDevice.isMasterPressed = true
		pieMenuDevice.boxX,pieMenuDevice.boxY = love.mouse.getPosition()

		if love.keyboard.isDown(settings.keys.modeKey) and not love.keyboard.isDown(settings.keys.layerKey) then pieMenuDevice.openModeSelection() end
		if not love.keyboard.isDown(settings.keys.modeKey) and love.keyboard.isDown(settings.keys.layerKey) then pieMenuDevice.openLayerSelection() end
		if love.keyboard.isDown(settings.keys.modeKey) and love.keyboard.isDown(settings.keys.layerKey) then pieMenuDevice.openMaterialSelection() end
		if not love.keyboard.isDown(settings.keys.modeKey) and not love.keyboard.isDown(settings.keys.layerKey) then pieMenuDevice.openToolSelection() end

		constructor.newMenu(pieMenuDevice.boxTexts,pieMenuDevice.boxValues)
		constructor.openPage(pieMenuDevice.currentPage)

		if settings.verboseLogging then
			print("labels:")
			for _,text in pairs(pieMenuDevice.boxTexts) do
				print("    "..text)
			end
			print("values:")
			for _,value in pairs(pieMenuDevice.boxValues) do
				print("    "..value)
			end
		end
	end
end

function pieMenuDevice.wheelmoved(dx, dy)
	if pieMenuDevice.isMasterPressed then
	    if dy > 0 then
		    pieMenuDevice.currentPage += 1
		    if pieMenuDevice.currentPage > constructor.pageCount then
			    pieMenuDevice.currentPage = 1
		    end
			constructor.openPage(pieMenuDevice.currentPage)

	    elseif dy < 0 then
		    pieMenuDevice.currentPage -= 1
		    if pieMenuDevice.currentPage < 1 then
			    pieMenuDevice.currentPage = constructor.pageCount
		    end
			constructor.openPage(pieMenuDevice.currentPage)
	    end
	return true
    end
end
--TODO move active/selected element logic here. very low prio. idk, maybe leaving it in draw is better. idk if or if not draw gets capped at 60fps or if it will also go up to 1000fps. if it does actually cap at 60, ill leave the logic in .draw
function pieMenuDevice.update(dt)
    if pieMenuDevice.isMasterPressed then
	    pieMenuDevice.masterPressedTime += 1
    end
end

function pieMenuDevice.keyreleased(key, scancode)
    if key == settings.keys.masterKey and pieMenuDevice.isMasterPressed then
	    pieMenuDevice.isMasterPressed = false

	    local name = nil
	    if pieMenuDevice.selectedEntry then
		     name = pieMenuDevice.boxValues[pieMenuDevice.selectedEntry]
		end
	    pieMenuDevice.closeLastMenu(name)
	    if lastTool and toolHandler.currentTool == emptyTool then
			toolHandler.currentTool = lastTool
			toolHandler.selectTool(lastTool.name)
			lastTool = nil
		end

	    pieMenuDevice.masterPressedTime = 0
	    constructor.releaseMenu()
	    pieMenuDevice.currentPage = 1
    end
end

function pieMenuDevice.getSelectedEntry()
	if #constructor.rings.count == 0 then
		return nil
	end
	local menuX = pieMenuDevice.boxX
	local menuY = pieMenuDevice.boxY
	local mx,my = love.mouse.getPosition()
	local dx = menuX-mx
	local dy = menuY-my
	local ringIndex = 1
	ringIndex = math.min(math.ceil((math.sqrt(dx*dx+dy*dy)/(settings.innerRadius)-.5)/2),#constructor.rings.count)

	if ringIndex == 0 then
		return nil
	end

	local bestScore = 1000000000
	local bestScoreGlobalEntryPosition = nil
	for n = 1, constructor.rings.count[ringIndex] do
		local X = constructor.rings.circlePosX[ringIndex][n]
		local Y = constructor.rings.posY[ringIndex][n]
		if (dx*X+dy*Y) < bestScore then
			bestScore = (dx*X+dy*Y)
			bestScoreGlobalEntryPosition = constructor.rings.globalEntryPosition[ringIndex][n]
		end
	end
	return bestScoreGlobalEntryPosition
end

--TODO make the selected entry get rendered ontop. and make that not selected ones get shortened if needed
function pieMenuDevice.draw()
	love.graphics.push()
	if pieMenuDevice.isMasterPressed then

		local pageLabel = pieMenuDevice.currentPage.."/"..constructor.pageCount
		pieMenuDevice.drawBox(0,0,pageLabel,font:getWidth(pageLabel),font:getHeight(pageLabel))

		pieMenuDevice.selectedEntry = pieMenuDevice.getSelectedEntry()

		for ringIndex = 1, settings.maxRingCount do
			local N = constructor.rings.count[ringIndex]
			if N then
				for n = 1, N do
					local x = constructor.rings.posX[ringIndex][n]
					local y = constructor.rings.posY[ringIndex][n]
					local label = constructor.rings.labels[ringIndex][n]
					local labelWidth =  constructor.rings.labelsWidth[ringIndex][n]
					local labelHeight =  constructor.rings.labelsHeight[ringIndex][n]
					if pieMenuDevice.selectedEntry == constructor.rings.globalEntryPosition[ringIndex][n] then
						pieMenuDevice.drawBox(x,y,label,labelWidth,labelHeight,true)
					else
						pieMenuDevice.drawBox(x,y,label,labelWidth,labelHeight,false)
					end
				end
			end
	    end
	end
    love.graphics.pop()
end

function pieMenuDevice.drawBox(x,y,label,labelWidth,labelHeight,isSelected,wasSelected)
		--oooo funny magic numbers
	local padding = settings.padding
	local X = x+pieMenuDevice.boxX
	local Y = y+pieMenuDevice.boxY
	love.graphics.setColor(0.1, 0.1, 0.1, 1)
-- 	local selectedIndex = pieMenuDevice.getSelectedEntry()
-- 	if option == toolHandler.currentToolName then love.graphics.setColor(0.1, 0.2, 0.4, 1) end
	if isSelected then love.graphics.setColor(0.2, 0.4, 0.8, 1) end
	love.graphics.rectangle("fill", X-(labelWidth+padding)/2, Y-(labelHeight+padding)/2, labelWidth + (padding * 2), labelHeight + (padding * 2), 1, 1)
	padding += 1
	love.graphics.setColor(0.7, 0.7, 0.7, 1)
	love.graphics.rectangle("line", X-(labelWidth+padding)/2, Y-(labelHeight+padding)/2, labelWidth + (padding * 2), labelHeight + (padding * 2), 1, 1)
	padding -= 1

--drawy labelHeight
	love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print(label, font, X-(labelWidth-padding)/2, Y-(labelHeight-padding)/2)
end



local _sceneHandlerChangeScene = sceneHandler.changeScene
function sceneHandler.changeScene(name, ...)
    _sceneHandlerChangeScene(name, ...)

    if name == "Editor" then
        local scene = sceneHandler.scenes[name]

--         Check if device is already in the input device list adn add to list if not ig. this doesnt celan up properly idk why
        for i, dev in ipairs(scene.inputDevices) do
            if dev == pieMenuDevice then
	            table.remove(scene.inputDevices,i)
                break
            end
        end

        table.insert(scene.inputDevices, 4, pieMenuDevice)
    end
end
