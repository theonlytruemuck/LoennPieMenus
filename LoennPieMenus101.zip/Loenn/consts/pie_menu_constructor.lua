local settings = require("mods").requireFromPlugin("consts.settings")
local serialize = require("utils.serialize")
local font = settings.font
local constructor = {}

constructor.maxPageEntries = 0
for k = 1, settings.maxRingCount do
	local ringCap = settings.ringCapacityFactor*(2*k-1)
	constructor.maxPageEntries += ringCap
end

function constructor.newMenu(entriesTexts,entriesValues)
	constructor.entriesTexts = entriesTexts
	constructor.entriesValues = entriesValues
	constructor.entryCount = #entriesValues
	constructor.computePageCount()
end

function constructor.openPage(page)
	constructor.computeRingCount()
	constructor.calculateRingSize(page)
	if settings.constructorLogging then
		print(serialize.serialize(constructor))
	end
end

function constructor.releaseMenu()
	local maxPageEntries = constructor.maxPageEntries
	for key,arg in pairs(constructor) do
		if type(arg) ~= "function" then
			constructor[key] = nil
		end
	end
	constructor.maxPageEntries = maxPageEntries
end

function constructor.computePageCount()
	constructor.pageCount = math.ceil(constructor.entryCount/constructor.maxPageEntries)
	constructor.lastPageEntryCount = constructor.entryCount-((constructor.pageCount-1)*constructor.maxPageEntries)
end

--this only really affects the last page, cause all the others can just get max ring capacities :3
function constructor.computeRingCount(onlyCompute)
	local maxRingCount = settings.maxRingCount
	local leftEntries = constructor.lastPageEntryCount
	local totalRingCap = 0
	for k = 1, maxRingCount do
		local ringCap = math.min(leftEntries,settings.ringCapacityFactor*(2*k-1))
		totalRingCap += ringCap
		leftEntries -= ringCap
		if leftEntries == 0 then
			if not onlyCompute then
				constructor.ringCount = k
			end
			return k
		end
	end
	if not onlyCompute then
		constructor.ringCount = maxRingCount
	end
	return maxRingCount
end

function constructor.calculateRingSize(page)
	local rings = {
		count = {},
		labels = {},
		labelsShort = {},
		labelsWidth = {},
		labelsHeight = {},
		values = {},
		posX = {},
		posY = {},
		globalEntryPosition = {},
		circlePosX = {}
	}

	constructor.pageSize = 0
	if page > constructor.pageCount then
		print("page exceeds max")
		constructor.rings = rings
		return rings
	end

	if page ~= constructor.pageCount then
		for k = 1, settings.maxRingCount do
			rings.count[k] = settings.ringCapacityFactor*(2*k-1)
			constructor.pageSize += settings.ringCapacityFactor*(2*k-1)
		end
	else
		local entryCount = 0
		for i = 1, constructor.ringCount do
			rings.count[i] = 0
		end

		while entryCount < constructor.lastPageEntryCount do
			for k = 1, constructor.ringCount do
				local ringCountOffset = math.min(constructor.lastPageEntryCount-entryCount,2*k-1)
				rings.count[k] += ringCountOffset
				entryCount += ringCountOffset
			end
		end
		constructor.pageSize = entryCount
	end
	for i = 1, settings.maxRingCount do
		rings.labels[i] ={}
		rings.labelsShort[i] ={}
		rings.labelsWidth[i] ={}
		rings.labelsHeight[i] ={}
		rings.values[i] = {}
		rings.posX[i] = {}
		rings.posY[i] = {}
		rings.globalEntryPosition[i] = {}
		rings.circlePosX[i] = {}
	end

	constructor.rings = rings
	for n = 1, #constructor.rings.count do
		constructor.buildRingData(page,n)
		constructor.computeEntryPositions(n)
	end
	return rings
end

function sign(x)
	if x > -x then
		return 1
	elseif x==-x then
		return 0
	else
		return -1
	end
end

function sqr(x)
	return x*x
end

function constructor.buildRingData(page,ringIndex)
	N = constructor.rings.count[ringIndex]
	for i = 1, N do
		local ringStart = 0
		for n=1, ringIndex-1 do
			ringStart += constructor.rings.count[n]
		end
		local globalEntryPosition = i+(math.max(0,page-1)*constructor.maxPageEntries)+ringStart
		constructor.rings.labels[ringIndex][i] = constructor.entriesTexts[globalEntryPosition]
		constructor.rings.values[ringIndex][i] = constructor.entriesValues[globalEntryPosition]
		constructor.rings.globalEntryPosition[ringIndex][i] = globalEntryPosition
		constructor.rings.labelsWidth[ringIndex][i] = font:getWidth(constructor.rings.labels[ringIndex][i])
		constructor.rings.labelsHeight[ringIndex][i] = font:getHeight(constructor.rings.labels[ringIndex][i])
	end
end

function constructor.computeEntryPositions(ringIndex)
	N = constructor.rings.count[ringIndex]
	local radius = settings.innerRadius
	local padding = settings.padding
	local r = (2*ringIndex-1)*radius
	if math.mod(N,2)==0 then
		for n = 1, N do
			local entryWidth = constructor.rings.labelsWidth[ringIndex][n]/2
			local v = (math.abs(N*0.5-n+1)-N*0.25)/(N*0.25)*r
			constructor.rings.posX[ringIndex][n] = sign(math.mod(n-1,N*0.5)*-(n-N*0.5-1))*(padding+entryWidth+math.sqrt(math.max(0,r*r-sqr(math.abs(v)))))
			constructor.rings.circlePosX[ringIndex][n] = sign(math.mod(n-1,N*0.5)*-(n-N*0.5-1))*(0.01+math.sqrt(math.max(0,r*r-sqr(math.abs(v)))))
			constructor.rings.posY[ringIndex][n] = -v
		end
	else
		for n = 1, N do
			local entryWidth = constructor.rings.labelsWidth[ringIndex][n]/2
			local v = ((math.abs(N*0.5-n+1)-0.5)-(N-1)*0.25)/((N-1)*0.25)*r
			constructor.rings.posX[ringIndex][n] = sign((N*0.5-n+1)*(n-1))*(padding+entryWidth+math.sqrt(math.max(0,r*r-sqr(math.abs(v)))))
			constructor.rings.circlePosX[ringIndex][n] = sign((N*0.5-n+1)*(n-1))*(0.01+math.sqrt(math.max(0,r*r-sqr(math.abs(v)))))
			constructor.rings.posY[ringIndex][n] = -v
		end
	end

end

return constructor
