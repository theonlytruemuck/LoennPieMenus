local settings ={}
settings.verboseLogging = false
settings.constructorLogging = false
settings.font = love.graphics.newFont(16)
settings.maxRingCount = 2

--i would reccomend setting this to an even number, since they give more symmetrical menus
settings.ringCapacityFactor = 16
settings.innerRadius = 90
settings.padding = 2

--Keybind support yaaayy
--i have not spent all to much time with this, so you cant rebind materials individually.
--they will walways be master+layer+mode
--make sure that ctrl and shift have an l for left or an r for right, otherwise lua will just crash or not load the plugin
settings.keys = {
	masterKey = "tab",
	layerKey = "lctrl",
	modeKey = "lshift"
}

return settings
